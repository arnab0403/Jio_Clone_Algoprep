//chat 
    setTimeout(() => {
        const container=document.querySelector(".container");
        const loadingScreen = document.querySelector('.loadingScreen');
        if (loadingScreen) {
          loadingScreen.style.display = 'none';
        }
        container.style.display="grid";
    }, 2000); // 2000 milliseconds = 2 seconds    
 



//explore

