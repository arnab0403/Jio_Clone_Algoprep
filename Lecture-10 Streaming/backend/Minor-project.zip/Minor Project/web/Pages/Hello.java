class java{
    {
        
    }
}