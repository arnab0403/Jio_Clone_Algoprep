//package packserver;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
//import java.util.Properties;
//import java.util.Random;
//import javax.servlet.http.HttpSession;
//
//
//
//
//public class VerifySignServlet extends HttpServlet {
//    String  vpass;
//    String vto, vfrom, vcc, vbcc, vsubject, vbody;
//
//    @Override
//    public void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        
//            PrintWriter out = response.getWriter();
//
//            String email = request.getParameter("email");
//            String pass = request.getParameter("password");
//            System.out.print(email);
//                HttpSession sess = request.getSession(true);
//                sess.setAttribute("password", pass);
//                vto=email;
//                vsubject="New OTP for Logging in !!!";
//                vbody="";
//                final String username ="socialiteofficialservice@gmail.com";
//                final String password = "vnmlrzxgvjeskzab";
//                Properties props = new Properties();
//                props.put("mail.smtp.ssl.protocols", "TLSv1.2");
//                props.put("mail.smtp.auth", "true");
//                props.put("mail.smtp.starttls.enable", "true");
//                props.put("mail.smtp.host", "smtp.gmail.com");
//                props.put("mail.smtp.port", "587");
//
//                Session session = Session.getInstance(props,
//                  new javax.mail.Authenticator() {
//                        @Override
//                        protected PasswordAuthentication getPasswordAuthentication() {
//                                return new PasswordAuthentication(username, password);
//                        }
//                  });
//
//            try {
//
//                    Message message = new MimeMessage(session);
//                    message.setFrom(new InternetAddress(username));
//                    message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(vto));
//                    message.setSubject(vsubject);
//                    Random random = new Random();
//                     int x = 0;
//                     while(x < 1000)
//                     {
//                         x = random.nextInt(9999);
//                     }
//                     vbody += "\n Hi "+"user"+", \n" +" \n We received a request to reset your password for your  Socialite account. If you requested this change, please don't share your password: \n "+ x+" \n If you have any questions, feel free to contact our support team at arnabdutta8584@gmail.com \n" +
//                    "\n" +
//                    "Best regards,\n" +
//                    "The SocaiLite Team";
//                    sess.setAttribute("otp",x);
//                    sess.setAttribute("email",email);
//                     
//                    message.setText(vbody);
//                    Transport.send(message);
//                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/verifyOtp.jsp");
//                    
//            } catch (MessagingException e) {
//                     response.sendRedirect("Pages/login.html?error="+e.getMessage());
//                     out.println("<h2 style='color:red'>"+e.getMessage()+"</h2>");
//                     out.println("<h2 style='color:red'>"+e.toString()+"</h2>");
//            }
//                    response.sendRedirect("/Pages/login.html");
//        } 
//    }

package packserver;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;
import javax.servlet.http.HttpSession;

public class VerifySignServlet extends HttpServlet {
    
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        PrintWriter out = response.getWriter();

        try {
            String email = request.getParameter("email");
            String pass = request.getParameter("password");

            HttpSession sess = request.getSession();
            sess.setAttribute("password", pass);

            String vto = email;
            String vsubject = "New OTP for Logging in!";
            final String username = "socialiteofficialservice@gmail.com";
            final String password = "vnmlrzxgvjeskzab"; // Consider moving this to a secure configuration

            Properties props = new Properties();
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                }
            );

            try {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(username));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(vto));
                message.setSubject(vsubject);

                Random random = new Random();
                int otp = random.nextInt(9000) + 1000;  // Generates a 4-digit OTP between 1000-9999

                String vbody = String.format(
                    "Hi %s,\n\nWe received a request to reset your password for your Socialite account." +
                    " If you requested this change, here is your OTP:\n\n%s\n\nIf you have any questions," +
                    " feel free to contact our support team at arnabdutta8584@gmail.com\n\nBest regards,\nThe Socialite Team",
                    "user", otp
                );

                sess.setAttribute("otp", otp);
                sess.setAttribute("email", email);

                message.setText(vbody);
                Transport.send(message);

                // Redirect to OTP verification page
                response.sendRedirect("http://localhost:8080/Minor_Project/Pages/verifyOtp.jsp");

            } catch (MessagingException e) {
                Logger.getLogger(VerifySignServlet.class.getName()).log(Level.SEVERE, null, e);
                response.sendRedirect("Pages/login.html?error=Unable to send email. Please try again.");
            }

        } catch (Exception ex) {
            Logger.getLogger(VerifySignServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect("Pages/login.html?error=An unexpected error occurred. Please try again.");
        } finally {
            out.close();
        }
    }
}
