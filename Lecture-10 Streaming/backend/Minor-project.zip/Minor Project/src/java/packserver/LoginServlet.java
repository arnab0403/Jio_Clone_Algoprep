package packserver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Get email and password from the request
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        // Database connection setup
        try (Connection con = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:ORCL", "SOCIALITE", "DHUP");
                
             PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM REGISTRATION WHERE email = ? AND password = ?")) {

            // Set email and password parameters
            ps.setString(1, email);
            ps.setString(2, password);

            // Execute the query
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // If credentials are correct, create a session and redirect to a welcome page
                HttpSession session = request.getSession();
                session.setAttribute("email", email);
                response.sendRedirect("index.html"); // Assuming you have a welcome.jsp page
            } else {
                // If credentials are incorrect, redirect back to the login page with an error
                response.sendRedirect("Pages/login.html?error=true");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("error.jsp"+e); // Redirect to a general error page
        }
    }
}
