package packserver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.Part;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;


public class AddFreelancer extends HttpServlet {

    String type,specialization,name,email,collegeName,year;
    OracleConnection oconn;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            type=request.getParameter("type");
            specialization=request.getParameter("specialization");
            name=request.getParameter("name");
            collegeName=request.getParameter("collegeName");
            year=request.getParameter("year");
            email=request.getParameter("email");
            
            oconn = (OracleConnection)DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","SOCIALITE","DHUP");
            PreparedStatement ps = oconn.prepareStatement("INSERT INTO FREELANCER (type, name, collegename, year, email,specialization) VALUES (?, ?, ?, ?, ?, ?)");
                ps.setString(1, type);
                ps.setString(2, name);
                ps.setString(3, collegeName);
                ps.setString(4, year);
                ps.setString(5, email);
                ps.setString(6,specialization);
            int rowCount = ps.executeUpdate();
            if(rowCount>0){
                response.sendRedirect("http://localhost:8080/Minor_Project/Pages/Dynamic/Freelancer.jsp?myParam=Product Added Succsessfully...!");
            }
            else{
                response.sendRedirect("http://localhost:8080/Minor_Project/Pages/Static/Addfreelancer.html?myParam=Opps..! There is something error...");
            }
            ps.close();
            oconn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AddProduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddProduct.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

}
