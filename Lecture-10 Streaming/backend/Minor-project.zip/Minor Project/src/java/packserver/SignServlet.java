package packserver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.Part;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpSession;


@MultipartConfig(maxFileSize = 16177215) 

public class SignServlet extends HttpServlet {
    String  vpass, vname;
    String vto, vfrom, vcc, vbcc, vsubject, vbody;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession sess = request.getSession(true);
        if(sess!=null){
            try (PrintWriter out = response.getWriter()) {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String firstName = request.getParameter("firstName");
            String middleName = request.getParameter("middleName");
            String pass=sess.getAttribute("password").toString();
            String lastName = request.getParameter("lastName");
            String email = sess.getAttribute("email").toString();
            String dateOfBirth = request.getParameter("date");
            String collegeName = request.getParameter("collegeName");
            String hobby = request.getParameter("hobby");
            String skill = request.getParameter("skill");
            String gender = request.getParameter("gender");
            
            

            // Parse the date string to java.sql.Date for database compatibility
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date utilDate = sdf.parse(dateOfBirth);
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            // Database operations
            try (Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:ORCL", "SOCIALITE", "DHUP");
                 PreparedStatement ps = con.prepareStatement(
                         "INSERT INTO REGISTRATION (email, firstName, middleName, lastName, password, dateOfBirth, collegeName, hobby, skill, gender, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {

                ps.setString(1, email);
                ps.setString(2, firstName);
                ps.setString(3, middleName);
                ps.setString(4, lastName);
                ps.setString(5, pass);
                ps.setDate(6, sqlDate);  // Use java.sql.Date
                ps.setString(7, collegeName);
                ps.setString(8, hobby);
                ps.setString(9, skill);
                ps.setString(10, gender);
                Part filePart = request.getPart("image"); // Retrieves <input type="file" name="image">
                InputStream fileContent = filePart.getInputStream();
                String fileName = filePart.getSubmittedFileName();
                long fileSize = filePart.getSize();
                ps.setBinaryStream(11, fileContent, (int) fileSize);

                int rowCount = ps.executeUpdate();
                if (rowCount > 0) {
//                vto=email;
//                vsubject="New OTP for Logging in !!!";
//                vbody="";
//                final String username ="socialiteofficialservice@gmail.com";
//                final String password = "vnmlrzxgvjeskzab";
//                Properties props = new Properties();
//                props.put("mail.smtp.ssl.protocols", "TLSv1.2");
//                props.put("mail.smtp.auth", "true");
//                props.put("mail.smtp.starttls.enable", "true");
//                props.put("mail.smtp.host", "smtp.gmail.com");
//                props.put("mail.smtp.port", "587");

//            Session session = Session.getInstance(props,
//              new javax.mail.Authenticator() {
//                    protected PasswordAuthentication getPasswordAuthentication() {
//                            return new PasswordAuthentication(username, password);
//                    }
//              });

//            try {
//
//                    Message message = new MimeMessage(session);
//                    message.setFrom(new InternetAddress(username));
//                    message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(vto));
//                    message.setSubject(vsubject);
//                    Random random = new Random();
//                     int x = 0;
//                     while(x < 1000)
//                     {
//                         x = random.nextInt(9999);
//                     }
//                     vbody += "\n Hi "+vname+", \n" +" \n We received a request to reset your password for your  Socialite account. If you requested this change, please don't share your password: \n "+ x+" \n If you have any questions, feel free to contact our support team at arnabdutta8584@gmail.com \n" +
//                    "\n" +
//                    "Best regards,\n" +
//                    "The SocaiLite Team";
//                    sess.setAttribute("otp",x);
//                    sess.setAttribute("email",email);
//                     
//                    message.setText(vbody);
//                    Transport.send(message);
//                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/verifyOtp.jsp");
//                    
//            } catch (MessagingException e) {
//                     response.sendRedirect("Pages/login.html?error="+e.getMessage());
//                     out.println("<h2 style='color:red'>"+e.getMessage()+"</h2>");
//                     out.println("<h2 style='color:red'>"+e.toString()+"</h2>");
//            }
                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/login.html");
                } else {
                    response.sendRedirect("error.jsp");
                }
            } catch (SQLException e) {
                Logger.getLogger(SignServlet.class.getName()).log(Level.SEVERE, "Database error: ", e);
                out.print("An error occurred during registration. Please try again later. "+e);
            }
        } catch (ParseException ex) {
            PrintWriter out = response.getWriter();
            Logger.getLogger(SignServlet.class.getName()).log(Level.SEVERE, "Date parsing error: ", ex);
            out.println("<h2 style='color:red'>"+ex.getMessage()+"</h2>");
            response.sendRedirect("error.jsp");
        } catch (ClassNotFoundException ex) {
            PrintWriter out = response.getWriter();
            Logger.getLogger(SignServlet.class.getName()).log(Level.SEVERE, null, ex);
            out.println("<h2 style='color:red'>"+ex.getMessage()+"</h2>");
        }
        }
        
    }
}
