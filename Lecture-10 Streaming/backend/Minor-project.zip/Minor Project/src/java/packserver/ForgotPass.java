package packserver;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class ForgotPass extends HttpServlet {
          OracleConnection oconn;
          OraclePreparedStatement ost;
          OracleResultSet ors = null;
          String vemail, vpass, vname;
          String vto, vfrom, vcc, vbcc, vsubject, vbody;


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Verifying Your Detalis</title>");            
            out.println("</head>");
            out.println("<body>");
            /* TODO output your page here. You may use following sample code. */
            vemail = request.getParameter("email");
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            oconn = (OracleConnection)DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","SOCIALITE","DHUP");
           ost =(OraclePreparedStatement) oconn.prepareStatement("SELECT * FROM REGISTRATION where email=?");
            ost.setString(1, vemail);
            ors = (OracleResultSet) ost.executeQuery();
            if(ors.next()) 
            {
                vto=vemail;
                vsubject="Forgot Password !!!";
                vbody="Please click the email below or copy paste it to reset your password";
                final String username ="socialiteofficialservice@gmail.com";
                final String password = "vnmlrzxgvjeskzab";
                Properties props = new Properties();
                props.put("mail.smtp.ssl.protocols", "TLSv1.2");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props,
              new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                    }
              });

            try {

                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(username));
                    message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(vto));
                    message.setSubject(vsubject);
                    vbody += "\n Click the link below or copy paste in browser address bar\n";
                    vbody += "\n http://localhost:8080/Minor_Project/Pages/VerifyQues.jsp?pemail="+vemail;
                    message.setText(vbody);
                    Transport.send(message);

                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/sociaLiteSecurity.html");
                    
            } catch (MessagingException e) {

                     out.println("<h2 style='color:red'>"+e.getMessage()+"</h2>");
                     response.sendRedirect("Pages/forgetpass.html?myParam="+e.getMessage());
            }
                
            }
            else 
            {
                response.sendRedirect("http://localhost:8080/TestWeb/Pages/WrongEmail.html");
            }
            ost.close();
            oconn.close();
        }     catch (SQLException ex) {
                  
                  Logger.getLogger(ForgotPass.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

}