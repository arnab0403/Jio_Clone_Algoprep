package packserver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@MultipartConfig(maxFileSize = 16177215) // for max 16 MB images

public class ImgServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    String vname;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String caption=request.getParameter("caption");
        HttpSession sess = request.getSession(false);
        vname= sess.getAttribute("fname").toString();
        Connection conn = null;

        try {
            // Register JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Open a connection
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "SOCIALITE", "DHUP");

            // Insert the movie into the database
            String sql = "INSERT INTO posts (NAME,CAPTION,LIKES,TIME,IMAGE) values (?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, vname);
            statement.setString(2,caption);
            statement.setInt(3,0);
            statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            Part filePart = request.getPart("image"); // Retrieves <input type="file" name="image">
            InputStream fileContent = filePart.getInputStream();
            String fileName = filePart.getSubmittedFileName();
            long fileSize = filePart.getSize();
            statement.setBinaryStream(5, fileContent, (int) fileSize);

                int row = statement.executeUpdate();

                if (row > 0) {
                    System.out.println(vname);
                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/index.jsp?status=success");

                }
                else
                {
                    response.sendRedirect("http://localhost:8080/Minor_Project/Pages/index.jsp?status=failed");
                }
            } catch (SQLException ex) {
            Logger.getLogger(ImgServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ImgServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}