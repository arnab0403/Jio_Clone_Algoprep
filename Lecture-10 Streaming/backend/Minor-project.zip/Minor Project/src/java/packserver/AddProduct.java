package packserver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.Part;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;


@MultipartConfig(maxFileSize = 16177215) 
public class AddProduct extends HttpServlet {

    String productName,location,email,collegeName;
    int productPrice;
    OracleConnection oconn;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            productName=request.getParameter("productName");
            location=request.getParameter("location");
            email=request.getParameter("email");
            collegeName=request.getParameter("collegeName");
            productPrice=Integer.parseInt(request.getParameter("productPrice"));
            oconn = (OracleConnection)DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","SOCIALITE","DHUP");
            PreparedStatement ps = oconn.prepareStatement("INSERT INTO PRODUCTS (productname, productimage, collegename, productprice, location, email) VALUES (?, ?, ?, ?, ?, ?)");
                ps.setString(1, productName);
                Part filePart = request.getPart("productImage"); // Retrieves <input type="file" name="image">
                InputStream fileContent = filePart.getInputStream();
                String fileName = filePart.getSubmittedFileName();
                long fileSize = filePart.getSize();
                ps.setBinaryStream(2, fileContent, (int) fileSize);
                ps.setString(3, collegeName);
                ps.setInt(4, productPrice);
                ps.setString(5, location);
                ps.setString(6, email);
            int rowCount = ps.executeUpdate();
            if(rowCount>0){
                response.sendRedirect("http://localhost:8080/Minor_Project/Pages/Dynamic/shop.jsp?myParam=Product Added Succsessfully...!");
            }
            else{
                response.sendRedirect("http://localhost:8080/Minor_Project/Pages/Static/Addproduct.html?myParam=Opps..! There is something error...");
            }
            ps.close();
            oconn.close();
            out.println(productName+" "+location+" "+email+" "+collegeName+" "+productPrice);
        } catch (SQLException ex) {
            Logger.getLogger(AddProduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddProduct.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

}
