/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packserver;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


public class InsertServ extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String age = request.getParameter("age");
        PrintWriter out;
        out= response.getWriter();
        try {
            // Replace with your Oracle database connection details
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "SOCIALITE", "DHUP");
            PreparedStatement ps = con.prepareStatement("INSERT INTO PRATICE (name, email, age) VALUES (?, ?, ?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, age);

            int rowCount = ps.executeUpdate();
            if (rowCount > 0) {
               response.sendRedirect("http://localhost:8080/Minor_Project/Pages/login.html" );// Redirect to a success page
            } else {
                response.sendRedirect("OPPPSS THERE IS SOMETHING ERROR________!"); // Redirect to an error page
            }
        } catch (ClassNotFoundException | SQLException | IOException e) {
            out.print(e);
        }
    }
}